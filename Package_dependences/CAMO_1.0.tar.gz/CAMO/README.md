# CAMO
Github repository for a molecular congruence analysis framework for evaluating model organisms (CAMO)


## Install this package from github
* In R console

```{R}
library(devtools)
install_github("https://github.com/CAMO-R/Rpackage") 
```


## Full tutorial (to be updated)


http://htmlpreview.github.io/?https://github.com/CAMO-R/Rpackage/blob/main/vignettes/CAMO.html

