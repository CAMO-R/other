## usethis namespace: start
#' @useDynLib CAMO, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
